# Portage Minecraft Java 26.3 — Locomotion

## État du portage

Cette branche prépare Locomotion pour Minecraft Java **26.3** à partir de la base
1.21.11 fournie dans l'archive. Elle cible **Fabric** et **NeoForge**. Le module
Forge présent dans l'archive d'origine reste désactivé.

**Ce dépôt est une base de portage, pas une version publiée ou validée en jeu.**
La compilation et les tests de lancement n'ont pas pu être exécutés dans
l'environnement de préparation : il ne disposait que de Java 21, alors que
Minecraft 26.3 demande Java 25, et l'accès réseau nécessaire pour installer un
JDK ou télécharger les dépendances Gradle n'était pas disponible.

## Modifications déjà appliquées

- Version Minecraft active portée de `1.21.11` à `26.3` pour les branches Fabric
  et NeoForge.
- Passage au JDK 25 et au wrapper Gradle 9.6.
- Remplacement de Loom classique par `dev.architectury.loom-no-remap`, car les
  versions récentes de Minecraft utilisent des classes non obfusquées.
- Suppression des couches de mappings Mojang/Parchment et des tâches de remap.
- Mise à jour des versions déclarées de Fabric Loader, Fabric API, NeoForge,
  YACL, Mod Menu et Sodium pour 26.3.
- Adaptation des tâches de distribution pour produire le JAR Shadow sans remap
  et y injecter l'Access Widener.
- Passage de la compatibilité Mixin à Java 25.
- Remplacement des appels `PoseStack.mulPose(Quaternionfc)` par `rotate` et de
  leur descripteur Mixin correspondant.
- Remplacement de l'accès dédié `EntityRenderDispatcher#getPlayerRenderer` par
  la recherche générique du renderer joueur.
- Retrait de champs inutilisés qui dépendaient de `ItemRenderer` et de
  `BlockRenderDispatcher`.
- Suppression de l'ancien mixin `BlockRenderDispatcher`, non utilisé ailleurs
  dans le projet et dépendant d'API de rendu retirées.

## Travail restant avant une version jouable

Locomotion modifie profondément le rendu des entités, des bras, des objets, des
capes et de la caméra. Le changement de moteur de rendu introduit en 26.3
(SDL/Renderpearl) affecte des points d'entrée et des signatures de méthodes
utilisés par plusieurs mixins. Les éléments suivants doivent encore être
compilés et validés contre les bibliothèques exactes de 26.3 :

- les injections de `MixinGameRenderer`, `MixinLivingEntityRenderer`,
  `MixinItemInHandRenderer` et `MixinEntityRenderDispatcher` ;
- les mixins de coffres et de boîtes de Shulker, qui ciblent des signatures de
  soumission de modèles ;
- le rendu à la première personne dans `FirstPersonPlayerRenderer`, notamment
  les appels au résolveur de modèles d'objets, aux états de rendu de cartes et
  aux couches de rendu ;
- les dépendances de configuration et l'intégration Mod Menu côté Fabric ;
- le lancement sur Fabric et NeoForge, ainsi que le comportement avec Sodium.

Certaines injections peuvent nécessiter une réécriture plutôt qu'un simple
changement de descripteur. Il ne faut donc pas considérer la présence des
versions 26.3 dans Gradle comme une garantie de compatibilité binaire.

## Construction

Installer un JDK 25, puis utiliser :

```bash
./gradlew chiseledBuild
```

Les artefacts collectés sont placés sous `build/libs/0.1.12/` par loader.

En cas d'échec, traiter d'abord les erreurs de compilation Java puis les erreurs
Mixin au lancement. Le portage n'est considéré terminé qu'après un lancement
client sur chaque loader et une vérification des animations de joueur, des objets
à la première personne, des coffres et des entités.
