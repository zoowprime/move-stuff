pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
        maven("https://maven.fabricmc.net/")
        maven("https://maven.architectury.dev")
        maven("https://maven.minecraftforge.net")
        maven("https://maven.neoforged.net/releases/")
//		maven("https://maven.kikugie.dev/snapshots")
    }
}

plugins {
    // Make sure the version here is the same as the dependency in buildSrc/build.gradle.kts.kts
    id("dev.kikugie.stonecutter") version "0.5.1"
}

stonecutter {
    centralScript = "build.gradle.kts"
    kotlinController = true
    create(rootProject) {
        versions("26.3")
        vcsVersion = "26.3"
        branch("fabric")
        // Forge is intentionally disabled; this port targets Fabric and NeoForge.
        branch("neoforge") { versions("26.3") }
    }
}

rootProject.name = "Locomotion"