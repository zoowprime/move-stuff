@file:Suppress("UnstableApiUsage")

plugins {
	id("dev.architectury.loom-no-remap")
	id("architectury-plugin")
}

val minecraft = stonecutter.current.version

version = "${prop("mod.version")}+$minecraft-playtesting"
base {
	archivesName.set("${prop("mod.id")}-common")
}

architectury.common(stonecutter.tree.branches.mapNotNull {
	if (stonecutter.current.project !in it) null
	else it.project.prop("loom.platform")
})

loom {
	accessWidenerPath = rootProject.file("src/main/resources/${prop("mod.id")}.accesswidener")

	decompilers {
		get("vineflower").apply { // Adds names to lambdas - useful for mixins
			options.put("mark-corresponding-synthetics", "1")
		}
	}
}

repositories {
	maven("https://maven.terraformersmc.com/")
	maven("https://maven.isxander.dev/releases")
	maven("https://api.modrinth.com/maven")
	maven {
		name = "Gegy"
		url = uri("https://maven.gegy.dev/releases/")
	}
}

dependencies {
	// Minecraft 26.3 ships unobfuscated game classes; Loom's remapping/mapping layer is not used.
	minecraft("com.mojang:minecraft:$minecraft")
	modImplementation("net.fabricmc:fabric-loader:${versionProp("fabric_loader")}")

	// Mod implementations
	modCompileOnly("dev.isxander:yet-another-config-lib:${versionProp("yacl_version")}-fabric")
}

tasks.processResources {
	applyProperties(project, listOf("${prop("mod.id")}-common.mixin.json"))
}

java {
	withSourcesJar()
	targetCompatibility = JavaVersion.VERSION_25
	sourceCompatibility = JavaVersion.VERSION_25
}

tasks.build {
	group = "versioned"
	description = "Must run through 'chiseledBuild'"
}